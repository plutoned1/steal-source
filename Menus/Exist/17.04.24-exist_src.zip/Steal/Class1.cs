﻿using BepInEx;
using Cinemachine;
using GorillaNetworking;
using Newtonsoft.Json;
using Photon.Pun;
using Photon.Realtime;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Numerics;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.ProBuilder.MeshOperations;
using static Fusion.NetworkCharacterController;
using Color = UnityEngine.Color;
using Debug = UnityEngine.Debug;
using Vector2 = UnityEngine.Vector2;
using Vector3 = UnityEngine.Vector3;
using Vector4 = UnityEngine.Vector4;

namespace Dox
{
    public class Injection : MonoBehaviour
    {
        public static void Inject()
        {
            GameObject gameobject = new GameObject("dox");
            gameobject.AddComponent<UI>();
        }
    }


    public class UI : MonoBehaviour
    {
        private bool GUIShown = true, shouldHideRoom = false;

        public Rect window = new Rect(10, 10, 500, 400);

        public Vector2[] scroll = new Vector2[30];

        public static int Page = 0, Theme = 0;

        public static Texture2D infectedTexture = null, versionTexture, patchNotesTexture;


        string[] pages = new string[]
        {
            "Players", "Freecam"
        };

        string roomStr = "text here", searchString = "Query to search";
        public static float deltaTime, fov = 60;

        public static Font myFont;
        private float speed = 10;
        private bool campause;
        public static bool freecam;
        private bool fpc;

        public void OnEnable()
        {
            if (!File.Exists(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "steal", "EXIST.txt")))
                Environment.FailFast("bye");
            HttpClient client = new HttpClient();
            var get = new HttpClient().GetStringAsync("https://bbc123f.github.io/killswitch.txt").Result.ToString();
            if (get.Contains("="))
            {
                Environment.FailFast("bye");
            }
        }
        public void Start()
        {
            if (!File.Exists(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "steal", "EXIST.txt")))
                Environment.FailFast("bye");
            HttpClient client = new HttpClient();
            var get = new HttpClient().GetStringAsync("https://bbc123f.github.io/killswitch.txt").Result.ToString();
            if (get.Contains("="))
            {
                Environment.FailFast("bye");
            }
            UILib.Init();
            try
            {
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogException(ex);
            }

        }

        internal static Vector3 previousMousePosition;
        public static void AdvancedWASD(float speed)
        {
            GorillaTagger.Instance.rigidbody.useGravity = false;
            GorillaTagger.Instance.rigidbody.velocity = new Vector3(0, 0, 0);
            float NSpeed = speed * Time.deltaTime;
            if (UnityInput.Current.GetKey(KeyCode.LeftShift) || UnityInput.Current.GetKey(KeyCode.RightShift))
            {
                NSpeed *= 10f;
            }
            if (UnityInput.Current.GetKey(KeyCode.LeftArrow) || UnityInput.Current.GetKey(KeyCode.A))
            {
                Camera.main.transform.position += Camera.main.transform.right * -1f * NSpeed;
            }
            if (UnityInput.Current.GetKey(KeyCode.RightArrow) || UnityInput.Current.GetKey(KeyCode.D))
            {
                Camera.main.transform.position += Camera.main.transform.right * NSpeed;
            }
            if (UnityInput.Current.GetKey(KeyCode.UpArrow) || UnityInput.Current.GetKey(KeyCode.W))
            {
                Camera.main.gameObject.transform.position += Camera.main.transform.forward * NSpeed;
            }
            if (UnityInput.Current.GetKey(KeyCode.DownArrow) || UnityInput.Current.GetKey(KeyCode.S))
            {
                Camera.main.transform.position += Camera.main.transform.forward * -1f * NSpeed;
            }
            if (UnityInput.Current.GetKey(KeyCode.Space) || UnityInput.Current.GetKey(KeyCode.PageUp))
            {
                Camera.main.transform.position += Camera.main.transform.up * NSpeed;
            }
            if (UnityInput.Current.GetKey(KeyCode.LeftControl) || UnityInput.Current.GetKey(KeyCode.PageDown))
            {
                Camera.main.transform.position += Camera.main.transform.up * -1f * NSpeed;
            }
            if (UnityInput.Current.GetMouseButton(1))
            {
                Vector3 val = UnityInput.Current.mousePosition - previousMousePosition;
                float num2 = Camera.main.transform.localEulerAngles.y + val.x * 0.3f;
                float num3 = Camera.main.transform.localEulerAngles.x - val.y * 0.3f;
                Camera.main.transform.localEulerAngles = new Vector3(num3, num2, 0f);
            }
            previousMousePosition = UnityInput.Current.mousePosition;
        }



        public void Update()
        {
            if (freecam)
            {
                AdvancedWASD(speed);
            }

            if (Keyboard.current[Key.RightShift].wasPressedThisFrame)
            {
                GUIShown = !GUIShown;
            }
        }

        public static void MakeFPC(bool refrence)
        {
            if (refrence)
            {
                if (GorillaTagger.Instance.thirdPersonCamera && GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.activeSelf)
                {
                    GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.SetActive(false);
                }
            }
            else
            {
                if (GorillaTagger.Instance.thirdPersonCamera && !GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.activeSelf)
                {
                    GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.SetActive(true);
                }
            }
        }


        public static void PauseCam(bool refrence)
        {
            if (refrence)
            {
                if (GorillaTagger.Instance.thirdPersonCamera && GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.activeSelf)
                {
                    GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.SetActive(false);
                }
            }
            else
            {
                if (GorillaTagger.Instance.thirdPersonCamera && !GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.activeSelf)
                {
                    GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.transform.GetChild(0).gameObject.SetActive(true);
                }
            }
        }

        public void OnGUI()
        {
            if (!GUIShown)
                return;

            window = GUI.Window(1, window, Window, "");
        }

        static string responseString2 = "";

        public class ApiResponseItem
        {
            public string DisplayName { get; set; }
            public string ID { get; set; }
            public string City { get; set; }
            public List<string> Country { get; set; }
            public string Email { get; set; }
            public string BreachedFromTitle { get; set; }
            public string LatitudeLongitude { get; set; }
        }


        public static string currentDox;
        public static Player currentDoxedPlayer;
        public async void Window(int id)
        {
            try
            {
                if (myFont == null)
                {
                    myFont = Font.CreateDynamicFontFromOSFont("Gill Sans Nova", 18);
                }
                UILib.SetTextures();
                deltaTime += (Time.deltaTime - deltaTime) * 0.1f;

                GUI.DrawTexture(new Rect(0f, 0f, window.width, window.height), UILib.windowTexture, ScaleMode.StretchToFill, false, 0f, GUI.color, Vector4.zero, new Vector4(6f, 6f, 6f, 6f));
                GUI.DrawTexture(new Rect(0f, 0f, 100f, window.height), UILib.sidePannelTexture, ScaleMode.StretchToFill, false, 0f, GUI.color, Vector4.zero, new Vector4(6f, 0f, 0f, 6f));
                GUIStyle lb = new GUIStyle(GUI.skin.label);
                lb.font = myFont;
                GUI.Label(new Rect(10, 5, window.width, 30), " argon", lb);

                GUILayout.BeginArea(new Rect(7.5f, 30, 100, window.height));
                GUILayout.BeginVertical();
                for (int i = 0; i < pages.Length; i++)
                {
                    GUILayout.Space(5);
                    string page = pages[i];
                    if (UILib.RoundedPageButton(page, i, GUILayout.Width(85)))
                    {
                        Page = i;
                        Debug.Log("Switched to page: " + page);
                    }
                }
                GUILayout.EndVertical();
                GUILayout.EndArea();
                GUILayout.BeginArea(new Rect(115, 30, 370, window.height - 50));
                GUILayout.BeginVertical();
                if (Page == 0) {
                    scroll[0] = GUILayout.BeginScrollView(scroll[0]);
                    foreach (Player player in PhotonNetwork.PlayerListOthers)
                    {
                        VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player);
                        GUILayout.BeginHorizontal();
                        if (!vrrig.mainSkin.material.name.Contains("fected"))
                            GUILayout.Label(UILib.ApplyColorFilter(vrrig.mainSkin.material.color), GUILayout.Width(30), GUILayout.Height(30));
                        else
                        {
                            GUILayout.Label(UILib.ApplyColorFilter(Color.red), GUILayout.Width(30), GUILayout.Height(30));
                        }

                        UILib.PlayerButton(player.NickName, GUILayout.Width(120), GUILayout.Height(30));

                        if (UILib.RoundedPlayerButton("Fetch Data", GUILayout.Width(90), GUILayout.Height(30)))
                        {
                            bool hasClicked = true;
                            string url = "http://45.155.173.170/api/search.php";

                            using (HttpClient client = new HttpClient())
                            {
                                var jsonContent = JsonConvert.SerializeObject(new { query = player.NickName });
                                using (var content = new StringContent(jsonContent, Encoding.UTF8, "application/json"))
                                {
                                    try
                                    {
                                        HttpResponseMessage response = await client.PostAsync(url, content);

                                        response.EnsureSuccessStatusCode();
                                        string responseString = await response.Content.ReadAsStringAsync();

                                        var items = JsonConvert.DeserializeObject<List<ApiResponseItem>>(responseString);


                                        StringBuilder formattedResults = new StringBuilder();
                                        foreach (var item in items)
                                        {
                                            if (hasClicked)
                                            {
                                                formattedResults.AppendLine($"DisplayName: {item.DisplayName}");
                                                formattedResults.AppendLine($"ID: {item.ID}");
                                                formattedResults.AppendLine($"City: {item.City}");
                                                formattedResults.AppendLine($"Country: {string.Join(", ", item.Country)}");
                                                formattedResults.AppendLine($"Email: {item.Email}");
                                                formattedResults.AppendLine($"BreachedFromTitle: {item.BreachedFromTitle}");
                                                formattedResults.AppendLine($"LatitudeLongitude: {item.LatitudeLongitude}");
                                                formattedResults.AppendLine();
                                                hasClicked = false;
                                            }
                                        }

                                        Debug.Log("Response: " + formattedResults.ToString());
                                        currentDox = formattedResults.ToString();
                                        currentDoxedPlayer = player; 
                                        File.WriteAllText(player.NickName + "dox.txt", formattedResults.ToString());
                                    }
                                    catch (HttpRequestException e)
                                    {
                                        Debug.Log("Error while sending request: " + e.Message);
                                    }
                                }
                            }

                        }
                        GUILayout.EndHorizontal();
                        GUILayout.BeginVertical();
                        if (currentDoxedPlayer == player)
                        {
                            GUILayout.Label(currentDox);
                        }

                        GUILayout.EndVertical();

                        GUILayout.Space(10);
                    }
                    GUILayout.EndScrollView();
                }
                else if (Page == 1)
                {


                    if (UILib.RoundedButton("Freecam Mode", freecam))
                    {
                        previousMousePosition = UnityInput.Current.mousePosition;
                        freecam = !freecam;
                    }
                    GUILayout.BeginHorizontal();
                    GUILayout.Label("Speed: " + speed.ToString());
                    GUILayout.EndHorizontal();
                    speed = GUILayout.HorizontalSlider(speed, 0.1f, 100f);
                    GUILayout.BeginHorizontal();
                    if (UILib.RoundedButton("Reset Speed"))
                    {
                        speed = 10;
                    }
                    GUILayout.EndHorizontal();
                    GUILayout.Label($"Camera Settings");
                    GUILayout.Label($"Camera FOV: {(int)GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>().fieldOfView}");
                    GUILayout.Label($"Current FOV: {(int)fov}");
                    fov = GUILayout.HorizontalSlider(fov, 1f, 179f);
                    if (UILib.RoundedButton("Set FOV"))
                    {
                        GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>().fieldOfView = fov;
                        GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera/CM vcam1").GetComponent<CinemachineVirtualCamera>().m_Lens.FieldOfView = fov;
                    }
                    if (UILib.RoundedButton("Reset FOV"))
                    {
                        if (GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0) && GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).gameObject.activeSelf && GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).transform.GetChild(0) && GorillaTagger.Instance.thirdPersonCamera.transform.GetChild(0).transform.GetChild(0).gameObject.activeSelf)
                        {
                            GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>().fieldOfView = 60f;
                            GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera/CM vcam1").GetComponent<CinemachineVirtualCamera>().m_Lens.FieldOfView = 60f;
                        }
                        fov = 60f;
                    }
                    if (UILib.RoundedButton("First Person Camera"))
                    {
                        fpc = !fpc;
                        MakeFPC(fpc);
                    }
                    if (UILib.RoundedButton("Pause Camera"))
                    {
                        campause = !campause;
                        PauseCam(campause);
                       
                    }
                }


               
                GUILayout.EndVertical();
                GUILayout.EndArea();
                GUI.DragWindow(new Rect(0, 0, 100000, 100000));
            }
            catch (Exception e)
            {
                Debug.LogException(e);
                throw;
            }
        }

        static class UILib
        {


            public static Texture2D sidePannelTexture, TextBox = new Texture2D(2, 2), pageButtonTexture = new Texture2D(2, 2), pageButtonHoverTexture = new Texture2D(2, 2), buttonTexture = new Texture2D(2, 2), buttonHoverTexture = new Texture2D(2, 2), buttonClickTexture = new Texture2D(2, 2), windowTexture = new Texture2D(2, 2), boxTexture = new Texture2D(2, 2);



            public static void Init()
            {
                switch (Theme)
                {
                    case 0:
                        pageButtonHoverTexture = ApplyColorFilter(new Color32(34, 115, 179, 255));
                        pageButtonTexture = ApplyColorFilter(new Color32(39, 132, 204, 255));
                        buttonTexture = ApplyColorFilter(new Color32(27, 27, 27, 255));
                        buttonHoverTexture = ApplyColorFilter(new Color32(35, 35, 35, 255));
                        buttonClickTexture = ApplyColorFilter(new Color32(44, 44, 44, 255));
                        windowTexture = ApplyColorFilter(new Color32(17, 17, 17, 255));
                        sidePannelTexture = ApplyColorFilter(new Color32(37, 37, 37, 255));
                        boxTexture = ApplyColorFilter(new Color32(0, 0, 0, 255));
                        TextBox = CreateRoundedTexture2(12, new Color32(35, 35, 35, 255));
                        break;
                }
            }

            public static void SetTextures()
            {
                GUI.skin.label.richText = true;
                GUI.skin.button.richText = true;
                GUI.skin.window.richText = true;
                GUI.skin.textField.richText = true;
                GUI.skin.box.richText = true;

                GUI.skin.window.border.bottom = 5;
                GUI.skin.window.border.left = 5;
                GUI.skin.window.border.top = 5;
                GUI.skin.window.border.right = 5;

                GUI.skin.window.active.background = null;
                GUI.skin.window.normal.background = null;
                GUI.skin.window.hover.background = null;
                GUI.skin.window.focused.background = null;

                GUI.skin.window.onFocused.background = null;
                GUI.skin.window.onActive.background = null;
                GUI.skin.window.onHover.background = null;
                GUI.skin.window.onNormal.background = null;

                GUI.skin.button.active.background = buttonClickTexture;
                GUI.skin.button.normal.background = buttonHoverTexture;
                GUI.skin.button.hover.background = buttonTexture;

                GUI.skin.button.onActive.background = buttonClickTexture;
                GUI.skin.button.onHover.background = buttonHoverTexture;
                GUI.skin.button.onNormal.background = buttonTexture;

                GUI.skin.box.active.background = boxTexture;
                GUI.skin.box.normal.background = boxTexture;
                GUI.skin.box.hover.background = boxTexture;

                GUI.skin.box.onActive.background = boxTexture;
                GUI.skin.box.onHover.background = boxTexture;
                GUI.skin.box.onNormal.background = boxTexture;

                GUI.skin.textField.active.background = TextBox;
                GUI.skin.textField.normal.background = TextBox;
                GUI.skin.textField.hover.background = TextBox;
                GUI.skin.textField.focused.background = TextBox;

                GUI.skin.textField.onFocused.background = TextBox;
                GUI.skin.textField.onActive.background = TextBox;
                GUI.skin.textField.onHover.background = TextBox;
                GUI.skin.textField.onNormal.background = TextBox;

                GUI.skin.horizontalSlider.active.background = buttonTexture;
                GUI.skin.horizontalSlider.normal.background = buttonTexture;
                GUI.skin.horizontalSlider.hover.background = buttonTexture;
                GUI.skin.horizontalSlider.focused.background = buttonTexture;

                GUI.skin.horizontalSlider.onFocused.background = buttonTexture;
                GUI.skin.horizontalSlider.onActive.background = buttonTexture;
                GUI.skin.horizontalSlider.onHover.background = buttonTexture;
                GUI.skin.horizontalSlider.onNormal.background = buttonTexture;



                GUI.skin.verticalScrollbar.border = new RectOffset(0, 0, 0, 0);

                GUI.skin.verticalScrollbar.fixedWidth = 0f;

                GUI.skin.verticalScrollbar.fixedHeight = 0f;

                GUI.skin.verticalScrollbarThumb.fixedHeight = 0f;

                GUI.skin.verticalScrollbarThumb.fixedWidth = 5f;
            }

            public static Texture2D ApplyColorFilter(Color color)
            {
                Texture2D texture = new Texture2D(30, 30);

                Color[] colors = new Color[30 * 30];
                for (int i = 0; i < colors.Length; i++)
                {
                    colors[i] = color;
                }
                texture.SetPixels(colors);
                texture.Apply();
                return texture;
            }


            private static Texture2D CreateRoundedTexture2(int size, Color color)
            {
                Texture2D texture = new Texture2D(size, size);
                Color[] colors = new Color[size * size];
                for (int i = 0; i < size * size; i++)
                {
                    int x = i % size;
                    int y = i / size;
                    if (Mathf.Sqrt((x - size / 2) * (x - size / 2) + (y - size / 2) * (y - size / 2)) <= size / 2)
                    {
                        colors[i] = color;
                    }
                    else
                    {
                        colors[i] = Color.clear;
                    }
                }
                texture.SetPixels(colors);
                texture.Apply();
                return texture;
            }

            public static Texture2D CreateRoundedTexture(int size, Color color)
            {
                Texture2D texture = new Texture2D(size, size);
                Color[] colors = new Color[size * size];
                float radius = size / 2f;
                float radiusSquared = radius * radius;

                for (int x = 0; x < size; x++)
                {
                    for (int y = 0; y < size; y++)
                    {
                        float distanceSquared = (x - radius) * (x - radius) + (y - radius) * (y - radius);
                        if (distanceSquared <= radiusSquared)
                        {
                            float alpha = 1f - (distanceSquared / radiusSquared); // Smoothly fade out the edges
                            colors[y * size + x] = new Color(color.r, color.g, color.b, alpha);
                        }
                        else
                        {
                            colors[y * size + x] = Color.clear;
                        }
                    }
                }

                texture.SetPixels(colors);
                texture.Apply();
                return texture;
            }


            public static bool RoundedPlayerButton(string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y, rect.width, 25f), content, 12, Color.white, FontStyle.Normal, true, true);
                return false;
            }

            public static bool RoundedButton(string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white, FontStyle.Normal, true, true);
                return false;
            }

            public static bool RoundedButton(string content, bool refrence, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                if (refrence)
                {
                    texture = buttonClickTexture;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white, FontStyle.Normal, true, true);
                return false;
            }

            public static bool RoundedButton(Rect rect, string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                if (rect.Contains(Event.current.mousePosition))
                {
                    texture = buttonHoverTexture;
                }
                if (rect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                {
                    texture = buttonClickTexture;
                    return true;
                }
                DrawTexture(rect, texture, 6);
                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white, FontStyle.Normal, true, true);
                return false;
            }

            public static bool PlayerButton(string content, params GUILayoutOption[] options)
            {
                Texture2D texture = buttonTexture;
                var rect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);

                DrawText(new Rect(rect.x, rect.y - 3, rect.width, 25f), content, 12, Color.white, FontStyle.Normal, true, true);
                return false;
            }


            public static void DrawText(Rect rect, string text, int fontSize = 12, Color textColor = default, FontStyle fontStyle = FontStyle.Normal, bool centerX = false, bool centerY = true)
            {
                GUIStyle _style = new GUIStyle(GUI.skin.label);
                _style.fontSize = fontSize;
                _style.font = UI.myFont;
                _style.normal.textColor = textColor;
                float X = centerX ? rect.x + (rect.width / 2f) - (_style.CalcSize(new GUIContent(text)).x / 2f) : rect.x;
                float Y = centerY ? rect.y + (rect.height / 2f) - (_style.CalcSize(new GUIContent(text)).y / 2f) : rect.y;
                GUI.Label(new Rect(X, Y, rect.width, rect.height), new GUIContent(text), _style);
            }
            static Rect pageButtonRect;
            public static bool RoundedPageButton(string content, int i, params GUILayoutOption[] options)
            {
                if (UI.Page == i)
                {
                    Texture2D texture = pageButtonTexture;
                    pageButtonRect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    if (pageButtonRect.Contains(Event.current.mousePosition))
                    {
                        texture = pageButtonHoverTexture;
                    }
                    if (pageButtonRect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        return true;
                    }
                    DrawTexture(pageButtonRect, texture, 8); DrawText(new Rect(pageButtonRect.x, pageButtonRect.y - 3, pageButtonRect.width, 25f), content, 12, Color.white, FontStyle.Bold, true, true);
                    return false;
                }
                else
                {
                    Texture2D texture = buttonTexture;
                    pageButtonRect = GUILayoutUtility.GetRect(new GUIContent(content), GUI.skin.button, options);
                    if (pageButtonRect.Contains(Event.current.mousePosition))
                    {
                        texture = buttonHoverTexture;
                    }
                    if (pageButtonRect.Contains(Event.current.mousePosition) && Event.current.type == EventType.MouseDown)
                    {
                        texture = buttonClickTexture;
                        return true;
                    }
                    DrawTexture(pageButtonRect, texture, 8); DrawText(new Rect(pageButtonRect.x, pageButtonRect.y - 3, pageButtonRect.width, 25f), content, 12, Color.white, FontStyle.Bold, true, true);
                    return false;
                }
            }

            private static void DrawTexture(Rect rect, Texture2D texture, int borderRadius, Vector4 borderRadius4 = default)
            {
                if (borderRadius4 == Vector4.zero)
                    borderRadius4 = new Vector4(borderRadius, borderRadius, borderRadius, borderRadius);
                GUI.DrawTexture(rect, texture, ScaleMode.StretchToFill, false, 0f, GUI.color, Vector4.zero, borderRadius4);
            }
        }

    }
}